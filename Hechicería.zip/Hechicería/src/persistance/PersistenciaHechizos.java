package persistance;

import model.LibroDeHechizos;
import model.Hechizo;
import model.CSVSerializable;
import config.RutasArchivo;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public interface PersistenciaHechizos {

    static void serializarHechizos(List<Hechizo> lista, String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(lista); 
            System.out.println(path);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    static List<Hechizo> deserializarHechizos(String path) throws ClassNotFoundException {
        List<Hechizo> toReturn = new ArrayList<>();
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            toReturn = (List<Hechizo>) entrada.readObject(); 
            System.out.println("Hechizos deserializados");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }
    
    static void guardarHechizosCSV(List<Hechizo> lista, String path) {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            escritor.write("id,nombre,creador,tipo\n"); 
            
            for (Hechizo hechizo : lista) {
                escritor.write(((CSVSerializable)hechizo).toCSV());
                escritor.newLine(); 
            }
            System.out.println(path);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    static List<Hechizo> cargarHechizosCSV(String path) {
        List<Hechizo> toReturn = new ArrayList<>();
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            lector.readLine(); 
            String datos;
            
            while ((datos = lector.readLine()) != null) {
                Hechizo hechizo = Hechizo.fromCSV(datos); 
                if (hechizo != null) {
                    toReturn.add(hechizo); 
                }
            }
            System.out.println("Hechizos cargados");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }


}
