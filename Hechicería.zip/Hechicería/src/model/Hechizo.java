package model;

import java.io.Serializable;
import java.util.Objects;
import config.RutasArchivo;

public class Hechizo implements Serializable, Comparable<Hechizo>, CSVSerializable {

    private static final long serialVersionUID = 1L;
    private final int id;
    private final String nombre;
    private final String creador;
    private final TipoHechizo tipo;

    public Hechizo(int id, String nombre, String creador, TipoHechizo tipo) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.tipo = tipo;

    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCreador() {
        return creador;
    }

    public TipoHechizo getTipo() {
        return tipo;
    }

    @Override
    public int compareTo(Hechizo otro) {
        return Integer.compare(this.id, otro.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Hechizo)) {
            return false;
        }

        Hechizo other = (Hechizo) obj;
        return this.id == other.id;
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + creador + "," + tipo.name();
    }

    public static Hechizo fromCSV(String lineaCSV) {
        String[] datos = lineaCSV.split(",");
        if (datos.length != 4) {
            return null;
        }

        try {
            int id = Integer.parseInt(datos[0]);
            String nombre = datos[1];
            String creador = datos[2];

            TipoHechizo tipo;
            String tipoString = datos[3];

            if (tipoString.equals("ATAQUE")) {
                tipo = TipoHechizo.ATAQUE;
            } else if (tipoString.equals("DEFENSA")) {
                tipo = TipoHechizo.DEFENSA;
            } else if (tipoString.equals("UTILIDAD")) {
                tipo = TipoHechizo.UTILIDAD;
            } else if (tipoString.equals("OSCURO")) {
                tipo = TipoHechizo.OSCURO;
            } else if (tipoString.equals("CURACION")) {
                tipo = TipoHechizo.CURACION;
            } else if (tipoString.equals("ENCANTAMIENTO")) {
                tipo = TipoHechizo.ENCANTAMIENTO;
            } else {
                return null;
            }

            return new Hechizo(id, nombre, creador, tipo);
        } catch (Exception e) {
            return null;
        }
    }
    
    @Override
    public String toString() {
        return "Hechizo(" + "id=" + id + ", nombre='" + nombre + "', creador='" + creador + "', tipo=" + tipo + ')';
    }
    
}
