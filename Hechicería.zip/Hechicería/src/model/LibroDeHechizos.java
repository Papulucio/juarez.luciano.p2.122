package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

public class LibroDeHechizos<T extends Hechizo> implements Serializable {

    private static final long serialVersionUID = 1L;
    private final List<T> listaElementos;

    public LibroDeHechizos() {
        this.listaElementos = new ArrayList<>();
    }


    public void paraCadaElemento(Consumer<T> accion) {
        listaElementos.forEach(accion);
    }
    
    public void agregar(T elemento) {
        if (!this.listaElementos.contains(elemento)) {
            this.listaElementos.add(elemento);
        }
    }

    public void ordenar() {

        listaElementos.sort(null); 
    }

    public void ordenar(Comparator<T> comparador) { 
        listaElementos.sort(comparador);
    }
    
    public List<Hechizo> filtrarPorTipo(TipoHechizo tipoBuscado) { 
        List<Hechizo> resultado = new ArrayList<>();
        for (T elemento : listaElementos) {
            if (elemento.getTipo() == tipoBuscado) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    public List<Hechizo> filtrarPorNombre(String palabra) {
        List<Hechizo> resultado = new ArrayList<>();
        for (T elemento : listaElementos) {
            if (elemento.getNombre().contains(palabra)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    public T obtenerPorIndice(int indice) {
       if (indice >= 0 && indice < listaElementos.size()) { 
           return listaElementos.get(indice);
       }
       return null; 
    }
    

    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(this.listaElementos);
        }
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            List<T> listaCargada = (List<T>) entrada.readObject();
            this.listaElementos.clear();
            this.listaElementos.addAll(listaCargada);
        }
    }

    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            escritor.write("id,nombre,creador,tipo\n");
            for (T elemento : this.listaElementos) {
                escritor.write(((CSVSerializable) elemento).toCSV());
                escritor.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String path) throws IOException {
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            lector.readLine();
            String datos;
            this.listaElementos.clear();
            while ((datos = lector.readLine()) != null) {
                Hechizo hechizo = Hechizo.fromCSV(datos);
                if (hechizo != null) {
                    this.agregar((T) hechizo); 
                }
            }
        }
    }

}
