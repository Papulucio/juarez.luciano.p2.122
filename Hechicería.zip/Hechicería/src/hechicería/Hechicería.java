package hechicería;

import config.RutasArchivo;
import java.io.IOException;
import model.Hechizo;
import model.TipoHechizo;
import model.LibroDeHechizos;
import persistance.PersistenciaHechizos;
import java.util.List;

public class Hechicería {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
       try{  
            LibroDeHechizos<Hechizo> libro = new LibroDeHechizos<>(); 

            libro.agregar (new Hechizo (1, "Expelliarmus", "Flitwick", TipoHechizo.DEFENSA));
            libro.agregar (new Hechizo (2, "Alohomora", "Desconocido", TipoHechizo.UTILIDAD));
            libro.agregar (new Hechizo (3, "Sectumsempra", "Severus Snape", TipoHechizo.OSCURO));
            libro.agregar (new Hechizo (4, "Lumos", "Desconocido", TipoHechizo.ENCANTAMIENTO));
            libro.agregar (new Hechizo (5, "Vulnera Sanentur", "Snape", TipoHechizo.CURACION));

            System.out.println("Hechizos:");
            libro.paraCadaElemento(h -> System.out.println(h)); 
        
            System.out.println("\nHechizos de tipo DEFENSA: ");
            libro.filtrarPorTipo(TipoHechizo.DEFENSA)
                 .forEach(h -> System.out.println(h));

            System.out.println("\nHechizos que contienen 'Lumos': ");
            libro.filtrarPorNombre("Lumos")
                 .forEach(h -> System.out.println(h));

            System.out.println("\nHechizos ordenados por ID: ");
            libro.ordenar(); 
            libro.paraCadaElemento(h -> System.out.println(h));

            System.out.println("\nHechizos ordenados por nombre:");
            libro.ordenar((h1, h2) -> h1.getNombre().compareTo(h2.getNombre()));
            libro.paraCadaElemento(h -> System.out.println(h));

            libro.guardarEnArchivo(RutasArchivo.getPathBinString()); 
            
            LibroDeHechizos<Hechizo> libroCargado = new LibroDeHechizos<>(); 
            libroCargado.cargarDesdeArchivo(RutasArchivo.getPathBinString());
            System.out.println("\nHechizos cargados desde archivo binario:");
            libroCargado.paraCadaElemento(h -> System.out.println(h));

            libro.guardarEnCSV(RutasArchivo.getPathCSVString());
            libroCargado.cargarDesdeCSV(RutasArchivo.getPathCSVString()); 
            System.out.println("\nHechizos cargados desde archivo CSV: ");
            libroCargado.paraCadaElemento(h -> System.out.println(h));

        } catch (IOException | ClassNotFoundException e) {
             System.err.println("Error: " + e.getMessage());
        }
    }
}

